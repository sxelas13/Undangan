
// Script: countdown, music toggle, RSVP form (local save + mailto fallback)

// Countdown to next event (akad date used for countdown)
(function(){
  // parse target date from data (20 Oct 2025 08:00)
  const target = new Date('2025-10-20T08:00:00');
  const daysEl = document.getElementById('cd-days');
  const hoursEl = document.getElementById('cd-hours');
  const minsEl = document.getElementById('cd-mins');

  function update(){
    const now = new Date();
    let diff = (target - now);
    if(diff <= 0){
      daysEl.textContent = '0';
      hoursEl.textContent = '0';
      minsEl.textContent = '0';
      return;
    }
    const days = Math.floor(diff / (1000*60*60*24));
    diff -= days * (1000*60*60*24);
    const hours = Math.floor(diff / (1000*60*60));
    diff -= hours * (1000*60*60);
    const mins = Math.floor(diff / (1000*60));
    daysEl.textContent = days;
    hoursEl.textContent = hours;
    minsEl.textContent = mins;
  }
  update();
  setInterval(update, 60*1000);
})();

// Music toggle
(function(){
  const audio = document.getElementById('bg-music');
  const btn = document.getElementById('toggle-music');
  let playing = false;
  btn.addEventListener('click', ()=>{
    if(!playing){ audio.play().catch(()=>{}); btn.textContent='Pause Musik'; playing=true }
    else{ audio.pause(); btn.textContent='Play Musik'; playing=false }
  });
})();

// RSVP form handling
(function(){
  const form = document.getElementById('rsvp-form');
  const success = document.getElementById('rsvp-success');
  const saveBtn = document.getElementById('save-local');

  form.addEventListener('submit', (e)=>{
    e.preventDefault();
    const data = {
      name: form.name.value.trim(),
      count: form.count.value,
      attend: form.attend.value,
      message: form.message.value.trim(),
      time: new Date().toLocaleString()
    };
    // Try to use mailto as fallback to send (this opens user's email client)
    // Helpful quick-working approach without server.
    const subject = encodeURIComponent('Konfirmasi Kehadiran: ' + data.name);
    const bodyLines = [
      'Nama: ' + data.name,
      'Jumlah Hadir: ' + data.count,
      'Kehadiran: ' + data.attend,
      'Pesan: ' + data.message,
      'Waktu kirim: ' + data.time
    ];
    const body = encodeURIComponent(bodyLines.join('\n'));
    // mailto - replace 'youremail@example.com' with actual email if desired.
    window.location.href = 'mailto:youremail@example.com?subject=' + subject + '&body=' + body;

    // also save to localStorage for host to review on the device
    const stored = JSON.parse(localStorage.getItem('rsvp_submissions') || '[]');
    stored.push(data);
    localStorage.setItem('rsvp_submissions', JSON.stringify(stored));

    success.hidden = false;
    setTimeout(()=> success.hidden = true, 4500);
    form.reset();
  });

  saveBtn.addEventListener('click', ()=>{
    const data = {
      name: form.name.value.trim() || '---',
      count: form.count.value || '1',
      attend: form.attend.value || 'Hadir',
      message: form.message.value.trim() || '',
      time: new Date().toLocaleString()
    };
    const stored = JSON.parse(localStorage.getItem('rsvp_submissions') || '[]');
    stored.push(data);
    localStorage.setItem('rsvp_submissions', JSON.stringify(stored));
    alert('Tersimpan lokal. Anda dapat melihat entri di localStorage pada perangkat ini.');
    form.reset();
  });
})();


AXEL & ROSE - Undangan Pernikahan (Single-page website)
---------------------------------------------
Ini paket berisi template undangan digital lengkap (single-page HTML/CSS/JS).
Silakan ekstrak dan ganti file gambar serta musik sesuai kebutuhan.

Isi paket:
 - index.html  -> Halaman utama
 - styles.css  -> Styling
 - script.js   -> Countdown, musik, RSVP (simpan lokal + mailto fallback)
 - images/     -> Foto placeholder (ganti dengan foto prewedding Anda)
 - README.txt  -> Petunjuk ini
 - LICENSE.txt -> Lisensi sederhana

Cara cepat men-deploy (GitHub Pages / Netlify):
  1. Buat repository GitHub baru (misal: axel-rose-invitation).
  2. Upload semua file (index.html di root).
  3. Aktifkan GitHub Pages (Settings -> Pages -> pilih branch main -> Save).
  4. Dalam beberapa menit akan muncul link: https://username.github.io/repo-name

Mengganti foto:
 - Ganti file di folder images/photo1.jpg, photo2.jpg, photo3.jpg dengan foto asli Anda.
 - Pastikan ukuran tidak terlalu besar agar loading cepat (~200-800 KB ideal).

Musik Latar:
 - Default di file index.html menunjuk ke contoh MP3 publik. Anda bisa menggantinya:
   <audio id="bg-music" loop><source src="YOUR_MP3_URL.mp3" type="audio/mpeg"></audio>
 - Atau gunakan embed YouTube (lihat README online) — perhatikan hak cipta.

RSVP / Buku Tamu:
 - Saat ini formulir menggunakan metode mailto:youremail@example.com (akan membuka aplikasi email tamu).
 - Untuk integrasi yang menyimpan respons di server/spreadsheet, gunakan:
    - Google Forms -> embed, atau
    - Formspree (https://formspree.io) -> ganti action form ke Formspree endpoint, atau
    - Netlify Forms jika deploy di Netlify (tambahkan data-netlify="true").

Ganti alamat email mailto:
 - Buka script.js dan ganti 'youremail@example.com' dengan alamat email yang ingin menerima konfirmasi.

Catatan penting:
 - Ganti link Google Maps di index.html dengan link maps yang benar jika perlu.
 - Jika mau saya bantu upload & setting GitHub Pages, beri tahu saya akses atau konfirmasi, dan saya akan pandu langkah demi langkah.

Tanggal acara di template:
 - Akad: 20 Oktober 2025 (08:00 WIB)
 - Resepsi: 2 November 2025 (08:00 WIB)
